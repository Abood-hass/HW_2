/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hw_2;

import java.util.ArrayList;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

/**
 *
 * @author AboodHassKov
 */
public class HW_2_Q1 extends Application {
    
    @Override
    public void start(Stage primaryStage) {
        ArrayList A = new ArrayList();
        A.add("Black");
        A.add("Red");
        A.add("Blue");
        A.add("Yallow");
        A.add("Gray");
        A.add("Cyan");
        
        ListView LV1 = new ListView();
        LV1.getItems().addAll(A);
        
        ListView LV2 = new ListView();
        
        Button copy = new Button("Copy");
        copy.setAlignment(Pos.CENTER);
        
        HBox H = new HBox(LV1,copy,LV2);
        
        copy.setText("Say 'Hello World'");
        copy.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                LV2.getItems().add(LV1.getItems().get(LV1.getSelectionModel().getSelectedIndex()));
            }
        });
        
        Pane root = new Pane();
        root.getChildren().add(H);
        
        Scene scene = new Scene(root, 300, 250);
        
        primaryStage.setTitle("Multiple-Selection Lists");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
