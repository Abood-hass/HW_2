/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hw_2;

import java.io.*;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.*;
import javafx.scene.text.*;
import javafx.stage.Stage;

/**
 *
 * @author AboodHassKov
 */
public class HW_2_Q4 extends Application {
    
        MessageDigest md;
        byte[] messageDigest;
        BufferedWriter writer;
    @Override
    public void start(Stage primaryStage) throws FileNotFoundException, IOException {
        writer = new BufferedWriter(new FileWriter("A:\\Documents\\Record.txt"));
        
//        /////////Screen=1/////////        //
        
////////Labels
        
        Label wel = new Label("Welcome");
        wel.setId("wel");
        Label L_Name = new Label("User Name");
        Text F = new Text();
        F.setStyle( "-fx-font-style: italic;\n" +
                    "    -fx-font-size: 10;\n" +
                    "    -fx-color:red;\n" +
                    "    -fx-float: left;");
        Label L_Pass = new Label("User Password");
        
////////Text Inputs
        
        TextField Name = new TextField();
        PasswordField Password = new PasswordField();
        
////////Buttons
        
        Button Login = new Button("Login");
        Button Exit = new Button("Exit");
        
        Login.setStyle("\n" +
"    -fx-border-radius: 10;\n" +
"    -fx-background-color: green;");
        
        Exit.setStyle("\n" +
"    -fx-border-radius: 10;\n" +
"    -fx-background-color: green;");
        
////////Adding Children
        
        HBox HBtn = new HBox(8,Login,Exit);
        
        GridPane GP1 = new GridPane();
        
//               0                  1                           2
/*0*/   GP1.add(wel,0,0);
/*1*/   GP1.add(L_Name,0,1);    GP1.add(Name,1,1);      
/*2*/   GP1.add(L_Pass,0,2);    GP1.add(Password,1,2);  
/*3*/   GP1.add(F,0,3);         GP1.add(HBtn,1,3);
        
        GP1.setAlignment(Pos.CENTER);
        StackPane root1 = new StackPane();
        
        root1.getChildren().add(GP1);
        
        Scene scene1 = new Scene(root1,300, 250);
        
        
//        /////////End Screen=1/////////        //
        
//        /////////Screen=2/////////        //
        
////////Buttons
        
        Button View = new Button("View All Students");
        
        Button Add = new Button("Add Student");
        
////////Adding Children
        
        HBox H3 = new HBox(10,View,Add);
        
        StackPane root2 = new StackPane();
        
        root2.getChildren().add(H3);
        
        H3.setAlignment(Pos.CENTER);
        
        Scene scene2 = new Scene(root2,300, 250);
        
//        /////////End Screen=2/////////        //
        Login.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                if(
                   Name.getText().isEmpty() ||
                   Password.getText().isEmpty()
                   ){
                    F.setText("Fill all Fields");
                }else{
                    try { 

                        md = MessageDigest.getInstance("MD5"); 
                        
                        messageDigest = md.digest(Password.getText().getBytes()); 
                        
                        BigInteger no = new BigInteger(1, messageDigest); 
                        
                        String hashtext = no.toString(16); 
                        while (hashtext.length() < 32) { 
                            hashtext = "0" + hashtext;
                            writer.write(Name.getText()+" : "+hashtext+"\n");
                        } 
                        writer.write(Name.getText()+" "+hashtext+"\n");
                    }  

                    catch (NoSuchAlgorithmException e) { 
                        throw new RuntimeException(e); 
                    } catch (IOException ex) {
                        Logger.getLogger(HW_2_Q4.class.getName()).log(Level.SEVERE, null, ex);
                    }
//                    out.print("Name : "+Name.getText()+"\\Password:"+Password.getText());
                    primaryStage.setScene(scene2);
                    scene2.getStylesheets().add("Style.css");
                    F.setText("");
                    Password.setText("");
                    Name.setText("");
                }
            }
        });
        
        
        Exit.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {    
                try {
                    writer.close();
                } catch (IOException ex) {
                    Logger.getLogger(HW_2_Q4.class.getName()).log(Level.SEVERE, null, ex);
                }
                Platform.exit();
                System.exit(0);
            }
        });
        
        
        Add.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                primaryStage.setScene(scene1);
            }
        });
        
        
        View.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                
            }
        });
        
        
        primaryStage.setTitle("Hello World!");
        primaryStage.setScene(scene1);
        scene1.getStylesheets().add("Style.css");
        scene2.getStylesheets().add("Style.css");
        primaryStage.show();
        
        
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
        
    }
    
}
