/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hw_2;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.*;
import java.util.ArrayList;
import java.util.Optional;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

/**
 *
 * @author AboodHassKov
 */
public class HW_2_q3 extends Application {
    
    @Override
    public void start(Stage primaryStage) {
        
        TextArea TA = new TextArea("");
        
        //////////////////////////////////////////////////////////
        
        MenuButton Colors = new MenuButton();
        
        MenuItem Black = new MenuItem("Black");
        MenuItem Red = new MenuItem("Red");
        MenuItem Blue = new MenuItem("Blue");
        MenuItem Green = new MenuItem("Green");
        MenuItem Yallow = new MenuItem("Yallow");
        
        Colors.getItems().addAll(Black,Red,Blue,Green,Yallow);
        
//        Font_Color.getChildren().add(A1);
        
        
        //////////////////////////////////////////////////////////
        Menu MB_File = new Menu("File");
        
        MenuItem  Exit_File = new MenuItem ("Exit");
        MenuItem  Close_File = new MenuItem ("Close");
        MenuItem  Open_File = new MenuItem ("Open");

        MB_File.getItems().add(Open_File);
        MB_File.getItems().add(Close_File);
        MB_File.getItems().add(Exit_File);
        
        //////////////////////////////////////////////////////////
        Open_File.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                FileChooser fileChooser = new FileChooser();
                File x = fileChooser.showOpenDialog(primaryStage);
                try{
                    Scanner S = new Scanner(x);
                    while(S.hasNext()){
                        TA.appendText(S.nextLine());
                    }
                }catch(Exception e){
                    TA.setText(e.getMessage());
                }
                
            }
        });
        //////////////////////////////////////////////////////////
        Close_File.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
               TA.setText("");
            }
        });
        //////////////////////////////////////////////////////////
        Exit_File.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                Platform.exit();
                System.exit(0);
            }
        });
        //////////////////////////////////////////////////////////
        
        Menu MB_Edit = new Menu("Edit");
        
        MenuItem  Edit_Font = new MenuItem ("Size");
        MenuItem  Edit_Color = new MenuItem ("Color");
        
        MB_Edit.getItems().add(Edit_Font);
        MB_Edit.getItems().add(Edit_Color);
        
        //////////////////////////////////////////////////////////
        Edit_Color.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                Dialog<String> Color_D = new ChoiceDialog<String>("Blue","Black","Red","Green","Yallwo");
                Color_D.setHeaderText("Select The Text Color");
                String color = Color_D.showAndWait().get();
                TA.setStyle("-fx-text-inner-color:"+color);
            }
        });
        //////////////////////////////////////////////////////////
        Edit_Font.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                TextInputDialog dialog = new TextInputDialog(TA.getFont().getSize()+"");
                dialog.setTitle("Text Input Dialog");
                dialog.setHeaderText("Input Text Font Size");

                Optional<String> Size = dialog.showAndWait();
                if (Size.isPresent()){
                    TA.setStyle("-fx-font-size:"+Size.get());
                }
            }
        });
        StackPane root = new StackPane();
        
        MenuBar MBar = new MenuBar(MB_File,MB_Edit);
        
        VBox V = new VBox(MBar,TA);
        
        root.getChildren().add(V);
        
        
        Scene scene = new Scene(root, 800, 600);
        
        root.setPadding(new Insets(8));
        
        primaryStage.setTitle("Hello World!");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
