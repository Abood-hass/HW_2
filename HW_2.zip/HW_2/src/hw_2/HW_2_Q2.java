/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hw_2;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

/**
 *
 * @author AboodHassKov
 */
public class HW_2_Q2 extends Application {
    double C;
    @Override
    public void start(Stage primaryStage) {
        Label Hint = new Label("Enter by Celsius form");
        Label Result = new Label();
        
        TextField Celsius = new TextField("0");
        
        
        
        ToggleGroup Rs = new ToggleGroup();
        
        RadioButton Fahrenheit = new RadioButton("Fahrenheit");
        RadioButton Kelvin = new RadioButton("Kelvin");
        
        Fahrenheit.setToggleGroup(Rs);
        Kelvin.setToggleGroup(Rs);
        
        VBox V = new VBox(Hint,Celsius,Fahrenheit,Kelvin,Result);
        
        Kelvin.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                double K = (C + 273.15);
                Result.setText(String.valueOf(K));
                C = Double.parseDouble(Celsius.getText());
            }
        });
        
        Fahrenheit.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                double F = (C * 9)/5 + 32;
                Result.setText(String.valueOf(F));
                C = Double.parseDouble(Celsius.getText());
            }
        });
        
        StackPane root = new StackPane();
        
        Scene scene = new Scene(root, 300, 250);
        root.getChildren().add(V);
        
        primaryStage.setTitle("Temperature-Conversion");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
